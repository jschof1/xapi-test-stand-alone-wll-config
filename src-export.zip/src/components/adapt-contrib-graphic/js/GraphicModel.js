import ComponentModel from 'core/js/models/componentModel';

export default class GraphicModel extends ComponentModel {}
