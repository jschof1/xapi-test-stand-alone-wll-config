export default new ENUM([
  'SMALL',
  'LARGE'
]);
