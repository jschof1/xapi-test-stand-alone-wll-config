import 'core/js/fixes/img.lazyload';
import 'core/js/fixes/reactHelpers.html';
